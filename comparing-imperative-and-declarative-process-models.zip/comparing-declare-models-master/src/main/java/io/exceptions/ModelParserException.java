package io.exceptions;

public class ModelParserException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1988082368386836346L;

	public ModelParserException(String msg) {
		super(msg);
	}
}
