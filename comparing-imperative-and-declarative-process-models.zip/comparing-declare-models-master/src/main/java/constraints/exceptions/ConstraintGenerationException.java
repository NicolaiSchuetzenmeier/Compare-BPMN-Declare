package constraints.exceptions;

public class ConstraintGenerationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3153886876347887095L;

	
	public ConstraintGenerationException(String msg) {
		super(msg);
	}
}
