package constraints.exceptions;

public class ModelGenerationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1590400751083789998L;

	public ModelGenerationException(String msg) {
		super(msg);
	}
}
