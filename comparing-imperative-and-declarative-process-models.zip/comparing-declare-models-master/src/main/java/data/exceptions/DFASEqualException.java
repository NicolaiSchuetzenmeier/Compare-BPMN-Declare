package data.exceptions;

public class DFASEqualException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -328531112465591641L;

	public DFASEqualException(String msg) {
		super(msg);
	}
}
