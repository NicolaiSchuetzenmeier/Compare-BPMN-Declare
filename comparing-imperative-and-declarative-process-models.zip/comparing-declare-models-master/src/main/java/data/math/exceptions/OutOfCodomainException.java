package data.math.exceptions;

public class OutOfCodomainException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1426613729256530536L;

}
